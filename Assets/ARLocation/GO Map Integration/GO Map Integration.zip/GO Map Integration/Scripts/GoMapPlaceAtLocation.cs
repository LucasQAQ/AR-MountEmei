using UnityEngine;

namespace ARLocation.GoMapIntegration
{
    public class GoMapPlaceAtLocation : MonoBehaviour
    {
        public PlaceAtLocation.LocationSettingsData LocationOptions;
        public PlaceAtLocation.PlaceAtOptions PlacementOptions;

        public GameObject Prefab;
        public GameObject GoMapPinPrefab;
        
        public bool DebugMode;

        InitalSceneController initalSceneController;
        LocationManager locationManager;
        GoMap.GOMap map;

        void Start()
        {
            initalSceneController = FindObjectOfType<InitalSceneController>();

            initalSceneController.OnArSceneLoaded += onArSceneLoadedListener;
            initalSceneController.OnGoMapSceneLoaded += onGoMapSceneLoadedListener;
        }

        void OnDestroy()
        {
            if (initalSceneController != null)
            {
                initalSceneController.OnArSceneLoaded -= onArSceneLoadedListener;
                initalSceneController.OnGoMapSceneLoaded -= onGoMapSceneLoadedListener;
            }

            if (locationManager != null)
            {
                locationManager.onLocationChanged.RemoveListener(onLocationChanged);
                locationManager.onOriginSet.RemoveListener(onOriginSet);
            }
        }

        GameObject mapPinInstance;
        private void onGoMapSceneLoadedListener()
        {
            locationManager = FindObjectOfType<LocationManager>();
            locationManager.onOriginSet.AddListener(onOriginSet);
            locationManager.onLocationChanged.AddListener(onLocationChanged);

            map = FindObjectOfType<GoMap.GOMap>();
        }

        void updateMapPin()
        {
            if (mapPinInstance == null)
            {
                mapPinInstance = GameObject.Instantiate(GoMapPinPrefab);
            }

            var loc = LocationOptions.GetLocation();
            map.dropPin(loc.Latitude, loc.Longitude, mapPinInstance);
        }

        private void onOriginSet(GoShared.Coordinates arg0)
        {
            if (initalSceneController.CurrentScene == SceneTag.GoMap)
            {
                updateMapPin();
            }
        }

        private void onLocationChanged(GoShared.Coordinates arg0)
        {
            if (initalSceneController.CurrentScene == SceneTag.GoMap)
            {
                updateMapPin();
            }
        }

        private void onArSceneLoadedListener()
        {
            if (mapPinInstance != null)
            {
                Destroy(mapPinInstance);
            }
            
            PlaceAtLocation.CreatePlacedInstance(Prefab, LocationOptions.GetLocation(), PlacementOptions, DebugMode);
        }
    }
}
