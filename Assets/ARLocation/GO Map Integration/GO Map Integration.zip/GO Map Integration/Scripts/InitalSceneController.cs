using System;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace ARLocation.GoMapIntegration
{
    
    public enum SceneTag
    {
        GoMap,
        Ar,
    };


    public class InitalSceneController : MonoBehaviour
    {

        public string GoMapSceneName = "GoMap Scene";
        public string ArSceneName = "AR Scene";

        public SceneTag StartingScene = SceneTag.GoMap;
        public SceneTag CurrentScene => currentScene;

        string startingSceneName => sceneNameForTag(StartingScene);

        public SceneTag currentScene;
        SceneTag sceneToLoad;
        AsyncOperation unloadSceneOperation;

        bool initalized = false;

        public Action OnGoMapSceneLoaded;
        public Action OnArSceneLoaded;
        

        string sceneNameForTag(SceneTag tag)
        {
            switch (tag)
            {
                case SceneTag.GoMap:
                    return GoMapSceneName;

                case SceneTag.Ar:
                    return ArSceneName;
            }

            return "";
        }

        void Start()
        {
            SceneManager.sceneLoaded += onSceneLoadedListener;
            SceneManager.LoadScene(startingSceneName, LoadSceneMode.Additive);
            initalized = true;
        }

        private void onSceneLoadedListener(Scene scene, LoadSceneMode mode)
        {
            Debug.Log($"[InitalSceneController][onSceneLoadedListener]: {scene.name}");
            
            if (scene.name == GoMapSceneName)
            {

                
                Debug.Log($"[InitalSceneController][onSceneLoadedListener]: going to {GoMapSceneName}");
                
                if (OnGoMapSceneLoaded != null)
                {
                    OnGoMapSceneLoaded.Invoke();
                }
                
            } 
            else if (scene.name == ArSceneName)
            {
                
                Debug.Log($"[InitalSceneController][onSceneLoadedListener]: going to {ArSceneName}");

                if (OnArSceneLoaded != null)
                {
                    OnArSceneLoaded.Invoke();
                }
                
            }
        }

        void OnDisable()
        {
            SceneManager.sceneLoaded -= onSceneLoadedListener;
        }

        public void LoadScene(SceneTag tag)
        {
            Debug.Log($"[InitalSceneController][LoadScene]: {tag}, {sceneNameForTag(tag)}");
            
            if (!initalized)
            {
                Debug.LogWarning("[InitalSceneController][LoadScene]: Not initalized; returning.");
                return;
            }

            if (tag != currentScene)
            {
                sceneToLoad = tag;
                unloadSceneOperation = SceneManager.UnloadSceneAsync(sceneNameForTag(currentScene));
            }
        }

        void Update()
        {
            if (unloadSceneOperation != null)
            {
                if (unloadSceneOperation.isDone)
                {
                    Debug.Log($"[InitalSceneController][Update]: Loading Scene: {sceneToLoad}, {sceneNameForTag(sceneToLoad)}");
                    SceneManager.LoadScene(sceneNameForTag(sceneToLoad), LoadSceneMode.Additive);
                    currentScene = sceneToLoad;
                    unloadSceneOperation = null;
                }
            }
        }
    }
}
