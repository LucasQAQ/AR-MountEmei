using System.Collections.Generic;
using UnityEngine;

namespace ARLocation.GoMapIntegration
{
    [CreateAssetMenu(fileName = "PrefabDb", menuName = "AR+GPS/Go Map PrefabDatabase")]
    public class GoMapPrefabDatabase : ScriptableObject
    {
        [System.Serializable]
        public class PrefabDatabaseEntry
        {
            /// <summary>
            ///   The `MeshId` associated with the prefab. Should match a `MeshId` from the data created
            ///   the Web Map Editor (https://editor.unity-ar-gps-location.com).
            /// </summary>
            public string MeshId;

            /// <summary>
            ///   The prefab you want to associate with the `MeshId`.
            /// </summary>
            public GameObject Prefab;

            public GameObject MapPinPrefab;
        }

        public List<PrefabDatabaseEntry> Entries;

        public PrefabDatabaseEntry GetEntryById(string Id)
        {
            PrefabDatabaseEntry result = null;

            foreach (var entry in Entries)
            {
                if (entry.MeshId == Id)
                {
                    result = entry;
                    break;
                }
            }

            return result;
        }

        public PrefabDatabase ToPrefabDatabase()
        {
            var result = ScriptableObject.CreateInstance<PrefabDatabase>();
            result.Entries = new List<PrefabDatabase.PrefabDatabaseEntry>();

            foreach (var entry in Entries)
            {
                result.Entries.Add(new PrefabDatabase.PrefabDatabaseEntry 
                        {
                            MeshId = entry.MeshId,
                            Prefab = entry.Prefab
                        });
            }

            return result;
        }
    }
}
