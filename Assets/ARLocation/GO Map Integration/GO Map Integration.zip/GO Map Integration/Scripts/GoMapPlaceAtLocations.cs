using System.Collections.Generic;
using UnityEngine;

namespace ARLocation.GoMapIntegration
{
    public class GoMapPlaceAtLocations : MonoBehaviour
    {
        public List<PlaceAtLocation.LocationSettingsData> Locations;
        public PlaceAtLocation.PlaceAtOptions PlacementOptions;
        public GameObject Prefab;
        public GameObject GoMapPinPrefab;
        public bool DebugMode;

        [HideInInspector]
        public List<GameObject> PlaceAtLocationInstances = new List<GameObject>();

        public void Awake()
        {
            foreach (var loc in Locations)
            {
                var go = new GameObject($"{name}_GoMapPlaceAtLocation");
                var goPlaceAt = go.AddComponent<GoMapPlaceAtLocation>();
                goPlaceAt.PlacementOptions = PlacementOptions;
                goPlaceAt.LocationOptions = loc;
                goPlaceAt.DebugMode = DebugMode;
                goPlaceAt.Prefab = Prefab;
                goPlaceAt.GoMapPinPrefab = GoMapPinPrefab;
            }
        }
    }
}
