using UnityEngine;
using UnityEngine.UI;

namespace ARLocation.GoMapIntegration
{
    public class ArSceneController : MonoBehaviour
    {
        public Button GotoArSceneButton;
        
        public string ArSceneName = "GoMap Scene";
        InitalSceneController initalSceneController;
        
        void OnEnable()
        {
            initalSceneController = FindObjectOfType<InitalSceneController>();
            GotoArSceneButton.onClick.AddListener(OnGotoArSceneButtonClicked);
        }

        void OnDisable()
        {
            GotoArSceneButton.onClick.RemoveListener(OnGotoArSceneButtonClicked);
        }

        private void OnGotoArSceneButtonClicked()
        {
            initalSceneController.LoadScene(SceneTag.GoMap);
        }
    }
}

