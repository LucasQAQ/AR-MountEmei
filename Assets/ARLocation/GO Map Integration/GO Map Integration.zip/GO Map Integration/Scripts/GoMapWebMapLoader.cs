using System.Collections.Generic;
using System.Xml;
using System.Globalization;
using UnityEngine;

namespace ARLocation.GoMapIntegration
{
    public class GoMapWebMapLoader : MonoBehaviour
    {

        public GoMapPrefabDatabase PrefabDatabase;
        public TextAsset XmlDataFile;
        public bool DebugMode;

        InitalSceneController initalSceneController;
        LocationManager locationManager;
        GoMap.GOMap map;


        // Start is called before the first frame update
        void Start()
        {
            initalSceneController = FindObjectOfType<InitalSceneController>();
            initalSceneController.OnArSceneLoaded += onArSceneLoadedListener;
            initalSceneController.OnGoMapSceneLoaded += onGoMapSceneLoadedListener;
        }

        void OnDestroy()
        {
            if (initalSceneController != null)
            {
                initalSceneController.OnArSceneLoaded -= onArSceneLoadedListener;
                initalSceneController.OnGoMapSceneLoaded -= onGoMapSceneLoadedListener;
            }

            if (locationManager != null)
            {
                locationManager.onLocationChanged.RemoveListener(onLocationChanged);
                locationManager.onOriginSet.RemoveListener(onOriginSet);
            }
        }


        private void onGoMapSceneLoadedListener()
        {
            if (webMapLoaderGo != null)
            {
                Destroy(webMapLoaderGo);
            }
            
            locationManager = FindObjectOfType<LocationManager>();
            locationManager.onOriginSet.AddListener(onOriginSet);
            locationManager.onLocationChanged.AddListener(onLocationChanged);

            map = FindObjectOfType<GoMap.GOMap>();

        }

        List<GameObject> mapPinInstances;
        List<WebMapLoader.DataEntry> dataEntries;

        void updateMapPins()
        {
            if (mapPinInstances == null)
            {
                LoadXmlFile();
                mapPinInstances = new List<GameObject>();

                foreach (var entry in dataEntries)
                {
                    var id = entry.meshId;

                    var prefab = PrefabDatabase.GetEntryById(id).MapPinPrefab;

                    var instance = Instantiate(prefab);

                    mapPinInstances.Add(instance);
                }
            }

            Debug.Assert(mapPinInstances.Count == dataEntries.Count);

            for (var i = 0; i < mapPinInstances.Count; i++)
            {
                var instance = mapPinInstances[i];
                var entry = dataEntries[i];
                map.dropPin(entry.lat, entry.lng, instance);
            }
        }

        private void onLocationChanged(GoShared.Coordinates arg0)
        {
            if (initalSceneController.CurrentScene == SceneTag.GoMap)
            {
                updateMapPins();
            }
        }

        private void onOriginSet(GoShared.Coordinates arg0)
        {
            if (initalSceneController.CurrentScene == SceneTag.GoMap)
            {
                updateMapPins();
            }

        }

        GameObject webMapLoaderGo;
        private void onArSceneLoadedListener()
        {
            if (mapPinInstances != null)
            {
                foreach (var i in mapPinInstances)
                {
                    Destroy(i);
                }
                
                mapPinInstances = null;
            }

            
            webMapLoaderGo = new GameObject($"{name}_WebMapLoader");
            var webMapLoader = webMapLoaderGo.AddComponent<WebMapLoader>();
            
            webMapLoader.PrefabDatabase = PrefabDatabase.ToPrefabDatabase();
            webMapLoader.XmlDataFile = XmlDataFile;
            webMapLoader.DebugMode = DebugMode;
        }

        void LoadXmlFile()
        {
            var xmlString = XmlDataFile.text;

            Debug.Log(xmlString);

            XmlDocument xmlDoc = new XmlDocument();

            try
            {
                xmlDoc.LoadXml(xmlString);
            }
            catch (XmlException e)
            {
                Debug.LogError("[GoMapWebMapLoader]: Failed to parse XML file: " + e.Message);
            }

            var root = xmlDoc.FirstChild;
            var nodes = root.ChildNodes;
            dataEntries = new List<WebMapLoader.DataEntry>();
            foreach (XmlNode node in nodes)
            {
                Debug.Log(node.InnerXml);
                Debug.Log(node["id"].InnerText);

                int id = int.Parse(node["id"].InnerText);
                double lat = double.Parse(node["lat"].InnerText, CultureInfo.InvariantCulture);
                double lng = double.Parse(node["lng"].InnerText, CultureInfo.InvariantCulture);
                double altitude = double.Parse(node["altitude"].InnerText, CultureInfo.InvariantCulture);
                string altitudeMode = node["altitudeMode"].InnerText;
                string name = node["name"].InnerText;
                string meshId = node["meshId"].InnerText;
                float movementSmoothing = float.Parse(node["movementSmoothing"].InnerText, CultureInfo.InvariantCulture);
                int maxNumberOfLocationUpdates = int.Parse(node["maxNumberOfLocationUpdates"].InnerText);
                bool useMovingAverage = bool.Parse(node["useMovingAverage"].InnerText);
                bool hideObjectUtilItIsPlaced = bool.Parse(node["hideObjectUtilItIsPlaced"].InnerText);

                var entry = new WebMapLoader.DataEntry()
                {
                    id = id,
                    lat = lat,
                    lng = lng,
                    altitudeMode = altitudeMode,
                    altitude = altitude,
                    name = name,
                    meshId = meshId,
                    movementSmoothing = movementSmoothing,
                    maxNumberOfLocationUpdates = maxNumberOfLocationUpdates,
                    useMovingAverage = useMovingAverage,
                    hideObjectUtilItIsPlaced = hideObjectUtilItIsPlaced
                };

                dataEntries.Add(entry);

                Debug.Log($"{id}, {lat}, {lng}, {altitude}, {altitudeMode}, {name}, {meshId}, {movementSmoothing}, {maxNumberOfLocationUpdates}, {useMovingAverage}, {hideObjectUtilItIsPlaced}");
            }
        }
    }
}
