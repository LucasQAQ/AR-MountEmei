using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

namespace ARLocation.GoMapIntegration
{
    public class GoMapSceneController : MonoBehaviour
    {
        public Button GotoArSceneButton;
        
        public string ArSceneName = "AR Scene";

        InitalSceneController initalSceneController;

        void Awake()
        {
            initalSceneController = FindObjectOfType<InitalSceneController>();
            Debug.Assert(initalSceneController != null);
        }
        
        void OnEnable()
        {
            GotoArSceneButton.onClick.AddListener(OnGotoArSceneButtonClicked);
        }

        void OnDisable()
        {
            GotoArSceneButton.onClick.RemoveListener(OnGotoArSceneButtonClicked);
        }

        private void OnGotoArSceneButtonClicked()
        {
            initalSceneController.LoadScene(SceneTag.Ar);
        }
    }
}
