using UnityEngine;

namespace ARLocation.GoMapIntegration
{
    public class LocationManager : GoShared.BaseLocationManager
    {
        public bool UseRawLocation;

        bool lateStart = false;
        private ARLocationProvider arLocationProvider;

        public void Awake()
        {
            arLocationProvider = FindObjectOfType<ARLocationProvider>();

            Debug.Assert(arLocationProvider != null);

            if (UseRawLocation)
            {
                arLocationProvider.OnRawLocationUpdated.AddListener(OnLocationUpdatedListener);
            }
            else
            {
                arLocationProvider.OnLocationUpdated.AddListener(OnLocationUpdatedListener);
            }

            if (arLocationProvider.IsEnabled)
            {
                lateStart = true;
            }
            
            // if (arLocationProvider.IsEnabled)
            // {
                // OnLocationUpdatedListener(arLocationProvider.CurrentLocation.ToLocation());
            // }

        }

        private void OnLocationUpdatedListener(Location location)
        {
            Debug.Log($"[LocationManager][OnLocationUpdatedListener] {location}");
            
            SetOrigin(LocationToCoordinates(location));
            currentLocation = LocationToCoordinates(location);

            if (onLocationChanged != null)
            {
                Debug.Log($"Calling onLocationChanged! {location}");
                onLocationChanged.Invoke(currentLocation);
            }

            if (onOriginSet != null)
            {
                Debug.Log($"Calling onLocationChanged! {location}");
                onOriginSet.Invoke(currentLocation);
            }
        }

        void Update()
        {
            if (lateStart)
            {
                OnLocationUpdatedListener(arLocationProvider.CurrentLocation.ToLocation());
                lateStart = false;
            }
        }
        
        public static GoShared.Coordinates LocationToCoordinates(Location loc)
        {
            return new GoShared.Coordinates(loc.Latitude, loc.Longitude);
        }
    }
}
